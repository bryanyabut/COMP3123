import './App.css';
import UserList from './UserList';

function App() {
  return (
    <div>
      <h1>Week 11 - Working with Axios</h1>
      <UserList/>
    </div>
  );
}

export default App;
